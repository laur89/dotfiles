#!/bin/bash
$fm_import

if [[ -f ~/.config/spacefm/.dropboxrc ]] ; then
	. ~/.config/spacefm/.dropboxrc
else
	echo "No config file found, run \"config/update\""
	exit 1
fi

unset URL

URL="https://www.dropbox.com/home"

if [[ -n "${BROWSERSFM}" ]] ; then
	"${BROWSERSFM}" "${URL}"
elif [[ -n "${BROWSER}" ]] ; then
	"${BROWSER}" "${URL}"
else
	xdg-open "${URL}"
fi

exit $?
