#!/bin/bash
$fm_import

if [[ -f ~/.config/spacefm/.dropboxrc ]] ; then
	. ~/.config/spacefm/.dropboxrc
else
	echo "No config file found, run \"config/update\""
	exit 1
fi

${DROPBOX_CLI} ls

exit $?
