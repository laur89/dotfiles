#!/bin/bash
#
# LICENSE
# Dropbox python script from nautilus-dropbox is under GPL-3
# http://linux.dropbox.com/packages/dropbox.py
#
# this bash script is in the public domain

$fm_import

die() {
	echo "$@"
	exit 1
}	

unset DROPBOXFOLDER CLIPBOARDCMD BROWSERSFM DROPBOX_CLI DROPBOX_CLI_DEFAULT PYTHONPATH DROPBOXDAEMON CLIVERSION

CLIVERSION="1"
DROPBOX_CLI_DEFAULT=~/.config/spacefm/.dropbox-cli.py

if [[ ! -f ~/.config/spacefm/.dropboxrc ]] ; then
	mkdir -p "$fm_cmd_data"

	# user interaction to set variables
	echo "Starting configuration..."
	echo
	echo "You may skip all configurations by hitting enter."
	echo "(this will set sane defaults, you can change them in"
	echo "~/.config/spacefm/.dropboxrc any time later)"
	echo
	echo "Type in your dropbox folder (default: ~/Dropbox):"
	read -e DROPBOXFOLDER
	echo
	echo "Set/choose your clipboard command here."
	echo "Valid values are \"0\", \"1\" or command string:"
	echo "0 for \"xclip -i -selection clipboard\" (default)"
	echo "1 for \"parcellite -c\""
	read -e CLIPBOARDCMD
	echo
	echo "Set path to BROWSER here. If skipped uses"
	echo "BROWSER env var or xdg-open:"
	read -e BROWSERSFM
	echo
	echo "Optional: Path to your dropbox-cli script"
	echo "(default: fetches and creates the script in ${DROPBOX_CLI_DEFAULT}):"
	read -e DROPBOX_CLI
	echo

	# finally set vars
	[[ -z "${DROPBOXFOLDER}" ]] && DROPBOXFOLDER=~/Dropbox
	if [[ "${CLIPBOARDCMD}" == 0 || -z "${CLIPBOARDCMD}" ]] ; then
		CLIPBOARDCMD="xclip -i -selection clipboard"
	elif [[ "${CLIPBOARDCMD}" == 1 ]] ; then
		CLIPBOARDCMD="parcellite -c"
	else
		CLIPBOARDCMD="${CLIPBOARDCMD}"
	fi
	[[ -z "${DROPBOX_CLI}" ]] && DROPBOX_CLI="${DROPBOX_CLI_DEFAULT}"

	# create config file
	cat << EOF > ~/.config/spacefm/.dropboxrc || die "creating config file failed"
## configuration file for dropbox spacefm plugin

# set your dropbox folder here
DROPBOXFOLDER=${DROPBOXFOLDER}

# set/choose your clipboard command here
#CLIPBOARDCMD="parcellite -c"
#CLIPBOARDCMD="xclip -i -selection clipboard"
CLIPBOARDCMD="${CLIPBOARDCMD}"

# set your BROWSER here
# if not set uses env BROWSER var or xdg-open
BROWSERSFM="${BROWSERSFM}"

# path to dropbox-cli python script
# make sure it's executable and you use python2
#DRPBOX_CLI="${DROPBOX_CLI_DEFAULT}"
#DROPBOX_CLI="/usr/bin/dropbox-cli"
DROPBOX_CLI="${DROPBOX_CLI}"
EOF

else
	# just update the cli-script if config file already exists
	. ~/.config/spacefm/.dropboxrc
	echo "Updating dropbox-cli script..."
fi

if [[ "${DROPBOX_CLI}" == ${DROPBOX_CLI_DEFAULT} || -z "${DROPBOX_CLI}" ]] ; then

	# re-set DROPBOX_CLI to default if it's unset
	if [[ -z "${DROPBOX_CLI}" ]] ; then
		sed \
			-e 's#DROPBOX_CLI.*$#DROPBOX_CLI="'${DROPBOX_CLI_DEFAULT}'"#' \
			-i ~/.config/spacefm/.dropboxrc || die "setting DROPBOX_CLI failed!"
	fi

	echo "Hit enter to wget the dropbox-cli script into"
	echo "${DROPBOX_CLI_DEFAULT}"
	echo "You have to accept GPL-3 license, abort if you don't!"
	read
	
	# remove old, wget new, extract and set executable
	rm "${DROPBOX_CLI_DEFAULT}.xz" "${DROPBOX_CLI_DEFAULT}" 2&>/dev/null
	wget -O "${DROPBOX_CLI_DEFAULT}.xz" \
		http://dev.gentoo.org/~hasufell/distfiles/dropbox-cli-${CLIVERSION}.py.xz || die "wget failed"
	xz -d "${DROPBOX_CLI_DEFAULT}.xz" || die "extracting failed! You need \"xz\"!"
	chmod +x "${DROPBOX_CLI_DEFAULT}" || die "making dropbox-cli.py executable failed!"

	# user interaction
	echo "Set path to python2 bin"
	echo "(hit enter for default: /usr/bin/python):"
	read -e PYTHONPATH
	echo

	if [[ -n "${PYTHONPATH}" ]] ; then
		sed \
			-e '1c\'"\#\!${PYTHONPATH}" \
			-i "${DROPBOX_CLI_DEFAULT}" \
			|| die "setting path to python2 failed!"
	else
		sed \
			-e '1c\'"\#\!/usr/bin/python" \
			-i "${DROPBOX_CLI_DEFAULT}" \
			|| die "setting path to python failed!"
	fi

	echo "Set path to dropboxd daemon"
	echo "(hit enter for default: \"/usr/bin/dropboxd\"):"
	read -e DROPBOXDAEMON
	echo

	if [[ -n "${DROPBOXDAEMON}" ]] ; then
		sed \
			-e 's#db_path = u"/usr/bin/dropboxd"#db_path = u"'${DROPBOXDAEMON}'"#' \
			-i "${DROPBOX_CLI_DEFAULT}" || die "setting path to dropboxd daemon failed!"
	fi

	echo "Dropbox cli script created successfully at ${DROPBOX_CLI_DEFAULT}"
else
	echo "Nothing to do, system dropbox-cli script is used."
	echo
fi

echo "Dropbox spacefm plugin is configured successfully!"
echo "Configuration file is ~/.config/spacefm/.dropboxrc"
echo "exiting..."

exit $?
